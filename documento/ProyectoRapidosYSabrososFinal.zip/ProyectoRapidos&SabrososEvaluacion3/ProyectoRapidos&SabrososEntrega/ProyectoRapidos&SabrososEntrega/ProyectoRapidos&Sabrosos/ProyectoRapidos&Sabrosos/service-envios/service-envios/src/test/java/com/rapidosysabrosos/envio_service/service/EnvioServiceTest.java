package com.rapidosysabrosos.envio_service.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import com.rapidosysabrosos.envio_service.model.Envio;
import com.rapidosysabrosos.envio_service.model.PedidoDTO;
import com.rapidosysabrosos.envio_service.repository.EnvioRepository;

import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class) // Habilita el uso de Mockito para aislamiento puro
public class EnvioServiceTest {

    @Mock
    private EnvioRepository envioRepository; // Simulamos el repositorio de base de datos

    @Mock
    private WebClient.Builder webClientBuilder; // Mock para interceptar las peticiones HTTP de WebClient

    @InjectMocks
    private EnvioService envioService; // Inyectamos automáticamente los mocks en tu servicio real

    @Test
    @DisplayName("Debería obtener un envío completo con sus datos de pedido enriquecidos")
    void obtenerEnvioCompletoTest() {
        // ----------------------------------------------------
        // FASE 1: PREPARACIÓN (Escenario / Given)
        // ----------------------------------------------------
        Long envioId = 1L;
        Long pedidoId = 500L;

        // Construimos el objeto Envio simulado con datos de prueba
        Envio envioMock = new Envio();
        envioMock.setIdEnvio(envioId);
        envioMock.setDireccionEnvio("Av. Siempreviva 742");
        envioMock.setEstadoEnvio("EN_CAMINO");
        envioMock.setTipoEnvio("EXPRESS");
        envioMock.setFechaEnvio(LocalDate.now());
        envioMock.setPedidoId(pedidoId);

        // Construimos el PedidoDTO que simulará la respuesta externa de la API de Pedidos
        PedidoDTO pedidoMock = new PedidoDTO();
        pedidoMock.setIdPedido(pedidoId);
        pedidoMock.setDescripcion("Hamburguesa con papas");
        pedidoMock.setTotal(15990.0);

        // Cuando el servicio busque en la base de datos por ID, Mockito devolverá nuestro envío simulado
        when(envioRepository.findById(envioId)).thenReturn(Optional.of(envioMock));

        // Desarmamos paso a paso la cadena reactiva de WebClient tal como lo pide el profesor
        WebClient webClient = Mockito.mock(WebClient.class);
        WebClient.RequestHeadersUriSpec uriSpec = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec headersSpec = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = Mockito.mock(WebClient.ResponseSpec.class);

        // Enlazamos secuencialmente los comportamientos de la cadena
        when(webClientBuilder.build()).thenReturn(webClient);
        when(webClient.get()).thenReturn(uriSpec);
        when(uriSpec.uri(anyString())).thenReturn(headersSpec);
        when(headersSpec.retrieve()).thenReturn(responseSpec);
        
        // Entregamos el pedido ficticio envuelto en un Mono reactivo para evitar que se quede pegado en el .block()
        when(responseSpec.bodyToMono(Object.class)).thenReturn(Mono.just(pedidoMock));

        
        // FASE 2: EJECUCIÓN (When)
        // Ejecutamos el método real de tu lógica de negocio
        Envio resultado = envioService.obtenerEnvioCompleto(envioId);

        // FASE 3: VERIFICACIÓN (Then)
        assertNotNull(resultado, "El envío no debe ser nulo");
        assertEquals("EN_CAMINO", resultado.getEstadoEnvio(), "El estado del envío debe ser EN_CAMINO");
        assertNotNull(resultado.getDatosPedido(), "Los datos del pedido deben haberse enriquecido correctamente");

        // Convertimos el Object devuelto a PedidoDTO para validar que sus datos internos no se alteraron
        PedidoDTO datosRetornados = (PedidoDTO) resultado.getDatosPedido();
        assertEquals("Hamburguesa con papas", datosRetornados.getDescripcion());
        assertEquals(pedidoId, datosRetornados.getIdPedido());

        // Comprobamos que se llamó al repositorio exactamente 1 vez
        verify(envioRepository, times(1)).findById(envioId);
    }

    // ====================================================
    // NUEVAS PRUEBAS PARA COMPLETAR EL MICROSERVICIO
    // ====================================================

    @Test
    @DisplayName("Debería listar todos los envíos existentes")
    void listarTodosTest() {
        // --- 1. PREPARACIÓN ---
        Envio envio1 = new Envio();
        envio1.setIdEnvio(1L);
        envio1.setDireccionEnvio("Calle Falsa 123");

        Envio envio2 = new Envio();
        envio2.setIdEnvio(2L);
        envio2.setDireccionEnvio("Av. Siempre Viva 742");

        // Simulamos que el repositorio devuelve una lista con 2 envíos
        java.util.List<Envio> listaMock = java.util.Arrays.asList(envio1, envio2);
        when(envioRepository.findAll()).thenReturn(listaMock);

        // --- 2. EJECUCIÓN ---
        java.util.List<Envio> resultado = envioService.listarTodos();

        // --- 3. VERIFICACIÓN ---
        assertNotNull(resultado);
        assertEquals(2, resultado.size(), "La lista debería contener exactamente 2 envíos");
        assertEquals("Calle Falsa 123", resultado.get(0).getDireccionEnvio());
        
        verify(envioRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Debería buscar un envío por ID de manera simple")
    void buscarPorIdTest() {
        // --- 1. PREPARACIÓN ---
        Long idBuscar = 1L;
        Envio envioMock = new Envio();
        envioMock.setIdEnvio(idBuscar);
        envioMock.setDireccionEnvio("Calle Principal 456");

        when(envioRepository.findById(idBuscar)).thenReturn(Optional.of(envioMock));

        // --- 2. EJECUCIÓN ---
        Optional<Envio> resultado = envioService.buscarPorId(idBuscar);

        // --- 3. VERIFICACIÓN ---
        assertTrue(resultado.isPresent(), "El envío debería ser encontrado");
        assertEquals("Calle Principal 456", resultado.get().getDireccionEnvio());
        
        verify(envioRepository, times(1)).findById(idBuscar);
    }

    @Test
    @DisplayName("Debería eliminar un envío por su ID correctamente")
    void eliminarTest() {
        // --- 1. PREPARACIÓN ---
        Long idEliminar = 1L;
        
        // Como el método deleteById es 'void' (no devuelve nada), 
        // no necesitamos usar 'when()'. Mockito por defecto no hace nada al llamarlo.

        // --- 2. EJECUCIÓN ---
        envioService.eliminar(idEliminar);

        // --- 3. VERIFICACIÓN ---
        // Aquí lo más importante es verificar que el repositorio realmente fue llamado
        verify(envioRepository, times(1)).deleteById(idEliminar);
    }

   
}
