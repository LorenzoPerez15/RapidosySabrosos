package com.rapidosysabrosos.service_productos.Service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue; 
import static org.mockito.Mockito.times;                  
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName; 
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.rapidosysabrosos.service_productos.Repository.CategoriaRepository;
import com.rapidosysabrosos.service_productos.Repository.ProductoRepository;
import com.rapidosysabrosos.service_productos.model.Producto;

@ExtendWith(MockitoExtension.class)
public class ProductoServiceTest {

    @Mock
    private ProductoRepository productoRepository;

    @Mock
    private CategoriaRepository categoriaRepository;

    @InjectMocks
    private ProductoService productoService;

    private Producto producto;

    @BeforeEach
    void setUp() {
        producto = new Producto();
        producto.setId_producto(1L);
        producto.setNombre("Hamburguesa");
        producto.setDescripcion("Hamburguesa doble");
        producto.setPrecio(5990);
        producto.setStock(20);
        producto.setDisponible(true);
    }

    @Test
    @DisplayName("Debería guardar un producto correctamente")
    void guardarProductoTest() {
        when(productoRepository.save(producto)).thenReturn(producto);
        Producto resultado = productoService.guardarProducto(producto);
        assertNotNull(resultado, "El producto guardado no debería ser nulo");
        assertEquals("Hamburguesa", resultado.getNombre());
        verify(productoRepository, times(1)).save(producto); // Formato estricto times(1)
    }

    @Test
    @DisplayName("Debería listar todos los productos")
    void listarProductosTest() {
        List<Producto> lista = Arrays.asList(producto);
        when(productoRepository.findAll()).thenReturn(lista);
        List<Producto> resultado = productoService.listarProductos();
        assertNotNull(resultado);
        assertEquals(1, resultado.size(), "La lista debería contener exactamente 1 producto");
        verify(productoRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Debería buscar un producto por su ID correctamente")
    void buscarProductoPorIdTest() {
        when(productoRepository.findById(1L)).thenReturn(Optional.of(producto));
        Optional<Producto> resultado = productoService.buscarProductoPorId(1L);
        assertTrue(resultado.isPresent(), "El producto debería estar presente en el Optional");
        assertEquals("Hamburguesa", resultado.get().getNombre());
        verify(productoRepository, times(1)).findById(1L);
    }

    @Test
    @DisplayName("Debería eliminar un producto por su ID")
    void eliminarProductoTest() {
        productoService.eliminarProducto(1L);
        verify(productoRepository, times(1)).deleteById(org.mockito.Mockito.anyLong());
    }
}