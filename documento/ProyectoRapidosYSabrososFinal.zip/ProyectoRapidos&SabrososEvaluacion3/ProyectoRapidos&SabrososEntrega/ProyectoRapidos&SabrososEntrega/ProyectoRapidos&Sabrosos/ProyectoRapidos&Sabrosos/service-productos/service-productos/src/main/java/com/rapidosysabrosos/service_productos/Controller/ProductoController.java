package com.rapidosysabrosos.service_productos.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rapidosysabrosos.service_productos.Service.ProductoService;
import com.rapidosysabrosos.service_productos.model.Producto;

@CrossOrigin(origins = "*") 
@RequestMapping("/api/v1/productos")
@RestController


public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @GetMapping // Cuando usamos una lista usamos GetMapping
    public List<Producto> listar(){
        return productoService.listarProductos();

    }

    @GetMapping("/{id}") // Buscar producto por ID
    public ResponseEntity<Producto> obtener(@PathVariable Long id){
        return productoService.buscarProductoPorId(id)
            // Si encuentra el producto retorna 200 OK
            .map(ResponseEntity::ok)
            // Si no existe retorna 404 NOT FOUND
            .orElse(ResponseEntity.notFound().build());

    }

    @PostMapping // Se ocupa cuando se vaya a agregar/crear algo
    public ResponseEntity<Producto> crear(@RequestBody Producto producto){
        return ResponseEntity.ok(productoService.guardarProducto(producto));

    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id){
        productoService.eliminarProducto(id);
        return ResponseEntity.noContent().build();

    }

}
