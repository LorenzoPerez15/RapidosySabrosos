package com.rapidosysabrosos.service_abastecimiento.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "abastecimiento")

public class Abastecimiento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idAbastecimiento;

    private Long idProducto;
    private Long idProveedor;

    private Double costo;
    private int tiempoEntrega;
    private int stockDisponibleProveedor;

     // Datos obtenidos desde otros microservicios
    @Transient
    private Object datosProducto;

    @Transient
    private Object datosProveedor;


}
