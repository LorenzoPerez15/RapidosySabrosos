package com.rapidosysabrosos.service_abastecimiento.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.rapidosysabrosos.service_abastecimiento.model.Abastecimiento;
import com.rapidosysabrosos.service_abastecimiento.repository.AbastecimientoRepository;

import jakarta.transaction.Transactional;

@Service
public class AbastecimientoService {

    @Autowired
    private AbastecimientoRepository abastecimientoRepository;

    @Autowired
    private WebClient.Builder webClientBuilder;

     // ===================== ABASTECIMIENTO =====================

        // Guardar abastecimiento
    public Abastecimiento guardarAbastecimiento(Abastecimiento abastecimiento) {
        return abastecimientoRepository.save(abastecimiento);
    }

    // Obtener abastecimiento por ID
    public Abastecimiento obtenerAbastecimiento(Long id) {
        return abastecimientoRepository.findById(id).orElse(null);
    }

    // Listar abastecimientos
    public List<Abastecimiento> listarAbastecimientos() {
        return abastecimientoRepository.findAll();
    }

    // Actualizar abastecimiento
    public Abastecimiento actualizar(Long id, Abastecimiento abastecimiento) {
        abastecimiento.setIdAbastecimiento(id);
        return abastecimientoRepository.save(abastecimiento);
    }

    // Eliminar abastecimiento
    public void eliminarAbastecimientoPorId(Long id) {
        abastecimientoRepository.deleteById(id);
    }

    // ===================== ABASTECIMIENTO COMPLETO =====================

    // Obtener abastecimiento completo
    public Abastecimiento obtenerAbastecimientoCompleto(Long id) {
        return abastecimientoRepository.findById(id)
                .map(a -> enriquecerConProveedor(enriquecerConProducto(a)))
                .orElse(null);
    }

    // Listar abastecimientos completos
    public List<Abastecimiento> listarTodos() {
        return abastecimientoRepository.findAll()
                .stream()
                .map(a -> enriquecerConProveedor(enriquecerConProducto(a)))
                .toList();
    }

    // ===================== ENRIQUECIMIENTO =====================

    // Enriquecer con producto
private Abastecimiento enriquecerConProducto(Abastecimiento abastecimiento) {

    if (abastecimiento.getIdProducto() == null) {
        return abastecimiento;
    }

    try {

        Object producto = webClientBuilder.build()
                .get()
                .uri("http://localhost:8083/api/v1/productos/"
                        + abastecimiento.getIdProducto())
                .retrieve()
                .bodyToMono(Object.class)
                .block();

        abastecimiento.setDatosProducto(producto);

    } catch (Exception e) {

        abastecimiento.setDatosProducto(
                "Información del producto no disponible");
    }

    return abastecimiento;
}

// Enriquecer con proveedor
private Abastecimiento enriquecerConProveedor(Abastecimiento abastecimiento) {

    if (abastecimiento.getIdProveedor() == null) {
        return abastecimiento;
    }

    try {

        Object proveedor = webClientBuilder.build()
                .get()
                .uri("http://localhost:8086/api/v1/proveedores/"
                        + abastecimiento.getIdProveedor())
                .retrieve()
                .bodyToMono(Object.class)
                .block();

        abastecimiento.setDatosProveedor(proveedor);

    } catch (Exception e) {

        abastecimiento.setDatosProveedor(
                "Información del proveedor no disponible");
    }

    return abastecimiento;
    }

}
