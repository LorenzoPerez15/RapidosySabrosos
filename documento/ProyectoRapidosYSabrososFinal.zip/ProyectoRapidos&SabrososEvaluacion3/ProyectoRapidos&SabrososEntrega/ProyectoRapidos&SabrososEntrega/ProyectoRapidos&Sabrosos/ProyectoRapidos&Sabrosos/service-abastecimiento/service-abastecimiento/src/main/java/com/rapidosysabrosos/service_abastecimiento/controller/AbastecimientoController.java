package com.rapidosysabrosos.service_abastecimiento.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rapidosysabrosos.service_abastecimiento.model.Abastecimiento;
import com.rapidosysabrosos.service_abastecimiento.service.AbastecimientoService;

@CrossOrigin(origins = "*") 
@RestController
@RequestMapping("/api/v1/abastecimientos")

public class AbastecimientoController {

     // ===================== ABASTECIMIENTO =====================

    @Autowired
    private AbastecimientoService abastecimientoService;

    // POST /api/v1/abastecimientos
    @PostMapping
    public ResponseEntity<Abastecimiento> crear(@RequestBody Abastecimiento abastecimiento) {
        Abastecimiento nuevo = abastecimientoService.guardarAbastecimiento(abastecimiento);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevo);
    }

    // GET /api/v1/abastecimientos
    @GetMapping
    public ResponseEntity<List<Abastecimiento>> listar() {
        return ResponseEntity.ok(abastecimientoService.listarAbastecimientos());
    }

    // GET /api/v1/abastecimientos/{id}/completo
    @GetMapping("/{id}/completo")
    public ResponseEntity<Abastecimiento> verAbastecimientoCompleto(@PathVariable Long id) {

        Abastecimiento abastecimiento = abastecimientoService.obtenerAbastecimientoCompleto(id);

        if (abastecimiento == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(abastecimiento);
    }

    // PUT /api/v1/abastecimientos/{id}
    @PutMapping("/{id}")
    public ResponseEntity<Abastecimiento> actualizar(@PathVariable Long id, @RequestBody Abastecimiento abastecimiento) {
        Abastecimiento actualizado = abastecimientoService.actualizar(id, abastecimiento);
        return ResponseEntity.ok(actualizado);
    }

    // DELETE /api/v1/abastecimientos/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        abastecimientoService.eliminarAbastecimientoPorId(id);
        return ResponseEntity.noContent().build();
    }
}
