package com.rapidosysabrosos.service_abastecimiento.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rapidosysabrosos.service_abastecimiento.model.Abastecimiento;

@Repository
public interface AbastecimientoRepository extends JpaRepository<Abastecimiento, Long>{

}
