package com.rapidosysabrosos.service_abastecimiento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceAbastecimientoApplicationTests {

	@Test
	void contextLoads() {
	}

}
