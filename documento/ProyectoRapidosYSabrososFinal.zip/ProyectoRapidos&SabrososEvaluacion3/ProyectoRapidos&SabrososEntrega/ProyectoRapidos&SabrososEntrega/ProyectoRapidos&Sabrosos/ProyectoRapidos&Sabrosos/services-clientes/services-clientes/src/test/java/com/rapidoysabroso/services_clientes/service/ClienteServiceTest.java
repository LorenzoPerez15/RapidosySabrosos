package com.rapidoysabroso.services_clientes.service;

import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import com.rapidoysabroso.services_clientes.Model.Cliente;
import com.rapidoysabroso.services_clientes.Repository.ClienteRepository;
import com.rapidoysabroso.services_clientes.Services.ClienteService;

@ExtendWith(MockitoExtension.class) //Usamos mockito para simular un objeto
class ClienteServiceTest {
    @Mock
    private ClienteRepository clienteRepository; //simulamos el repositorio
    @InjectMocks
    private ClienteService clienteService; //Inyectamos el mock en el servicio real
    @Test
    @DisplayName("Deberia guardar un cliente correctamente")
    //aqui creas los datos de la prueba y defines como debe comportarse tu "doble" (el repositorio)
    void guardarClienteTest() {
        //Preparacion
        Cliente cliente = new Cliente();
        cliente.setNombre("Juan");
        cliente.setRun("11222333-4");
        cliente.setCorreo("juan@correo.com");  
        //Simulamos que cuando el repo guarde cualquier cliente, retorne el mismo cliente con un ID asignado
        //Como no queremos usar una base de datos real, le decimos al Mockito:
        //"Cuando alguien llame al método .save() del repositorio con cualquier objeto de tipo Cliente
        //(any(Cliente.class))..."
        when(clienteRepository.save(any(Cliente.class))).thenAnswer(invocation -> {
            Cliente c = invocation.getArgument(0); //Obtenemos el cliente que se le pasó al save
            c.setIdCliente(1L); //Le asignamos un ID simulado
            return c; //Retornamos el cliente con el ID asignado
        });
        //2. Ejecución (When)Llamas al metodo real de tu logica de negocio
        //Estás ejecutando el codigo que tu escribiste en el Service. El Service,
        //internamente, llamará al metodo clienteRepository.save(). Como lo configuraste el 
        //"simulacro" en el paso anterior, el Service recibirá el cliente con el ID 1.
        Cliente resultado = clienteService.guardar(cliente);
        //3. Verificación (Then)Aquí verificas que el resultado sea el esperado
        assertNotNull(resultado); //Verificamos que el resultado no sea nulo
        assertEquals(1L, resultado.getIdCliente()); //Verificamos que el ID sea el esperado
        assertEquals("Juan", resultado.getNombre()); //Verificamos que el nombre sea el esperado
        assertEquals("juan@correo.com", resultado.getCorreo()); //Verificamos que el correo sea el esperado
        //Verificamos que el ID se haya asignado correctamente
        //llamara al repositorio dos veces por error, el test falllará
        verify(clienteRepository, times(1)).save(cliente);
    }
}
