package com.rapidosysabrosos.service_repartidor.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rapidosysabrosos.service_repartidor.model.Repartidor;


public interface RepartidorRepository extends JpaRepository<Repartidor, Long>{

}
