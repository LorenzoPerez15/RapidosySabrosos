package com.rapidosysabrosos.service_repartidor;

import com.rapidosysabrosos.service_repartidor.model.Repartidor;
import com.rapidosysabrosos.service_repartidor.repository.RepartidorRepository;
import com.rapidosysabrosos.service_repartidor.service.RepartidorService;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class RepartidorServiceTest {

    @Mock
    private RepartidorRepository repartidorRepository;

    @InjectMocks
    private RepartidorService repartidorService;

    @Test
    @DisplayName("Debería guardar un repartidor correctamente")
    void guardarRepartidorTest() {

        // Preparación
        Repartidor repartidor = new Repartidor();
        repartidor.setNombreRepartidor("Juan Pérez");
        repartidor.setTelefonoRepartidor(987654321L);
        repartidor.setTipoVehiculo("Moto");
        repartidor.setPatente("ABCD12");
        repartidor.setIdEnvio(1L);

        when(repartidorRepository.save(any(Repartidor.class)))
                .thenAnswer(invocation -> {
                    Repartidor r = invocation.getArgument(0);
                    r.setIdRepartidor(1L);
                    return r;
                });

        // Ejecución
        Repartidor resultado = repartidorService.guardar(repartidor);

        // Verificación
        assertNotNull(resultado);
        assertEquals(1L, resultado.getIdRepartidor());
        assertEquals("Juan Pérez", resultado.getNombreRepartidor());
        assertEquals(987654321L, resultado.getTelefonoRepartidor());
        assertEquals("Moto", resultado.getTipoVehiculo());
        assertEquals("ABCD12", resultado.getPatente());
        assertEquals(1L, resultado.getIdEnvio());

        verify(repartidorRepository, times(1)).save(repartidor);
    }

    @Test
    @DisplayName("Debería buscar un repartidor por ID")
    void buscarPorIdTest() {

        Repartidor repartidor = new Repartidor();
        repartidor.setIdRepartidor(1L);
        repartidor.setNombreRepartidor("Juan Pérez");

        when(repartidorRepository.findById(1L))
                .thenReturn(java.util.Optional.of(repartidor));

        Repartidor resultado = repartidorService.buscarPorId(1L);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getIdRepartidor());
        assertEquals("Juan Pérez", resultado.getNombreRepartidor());

        verify(repartidorRepository, times(1)).findById(1L);
    }

    @Test
    @DisplayName("Debería actualizar un repartidor")
    void actualizarRepartidorTest() {

        Repartidor existente = new Repartidor();
        existente.setIdRepartidor(1L);
        existente.setNombreRepartidor("Juan");

        Repartidor actualizado = new Repartidor();
        actualizado.setNombreRepartidor("Pedro");
        actualizado.setTelefonoRepartidor(999999999L);
        actualizado.setTipoVehiculo("Auto");
        actualizado.setPatente("XYZ123");
        actualizado.setIdEnvio(2L);

        when(repartidorRepository.findById(1L))
                .thenReturn(java.util.Optional.of(existente));

        when(repartidorRepository.save(any(Repartidor.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        Repartidor resultado = repartidorService.actualizar(1L, actualizado);

        assertNotNull(resultado);
        assertEquals("Pedro", resultado.getNombreRepartidor());
        assertEquals(999999999L, resultado.getTelefonoRepartidor());
        assertEquals("Auto", resultado.getTipoVehiculo());
        assertEquals("XYZ123", resultado.getPatente());
        assertEquals(2L, resultado.getIdEnvio());

        verify(repartidorRepository).findById(1L);
        verify(repartidorRepository).save(any(Repartidor.class));
    }

    @Test
    @DisplayName("Debería eliminar un repartidor")
    void eliminarRepartidorTest() {

        Long id = 1L;

        doNothing().when(repartidorRepository).deleteById(id);

        repartidorService.eliminar(id);

        verify(repartidorRepository, times(1)).deleteById(id);
    }
}