package com.rapidosysabrosos.service_repartidor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceRepartidorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceRepartidorApplication.class, args);
	}

}
