package com.rapidosysabrosos.service_repartidor.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Repartidor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idRepartidor;

    private Long telefonoRepartidor;

    private String nombreRepartidor;

    private String tipoVehiculo;

    private String patente;

    private Long idEnvio;

    @Transient
    private Object datosEnvio;
}
