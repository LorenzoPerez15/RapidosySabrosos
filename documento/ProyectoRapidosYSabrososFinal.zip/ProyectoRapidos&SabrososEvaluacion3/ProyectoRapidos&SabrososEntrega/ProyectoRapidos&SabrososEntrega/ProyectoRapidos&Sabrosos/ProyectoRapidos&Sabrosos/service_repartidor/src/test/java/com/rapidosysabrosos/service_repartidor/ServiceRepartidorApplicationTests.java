package com.rapidosysabrosos.service_repartidor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRepartidorApplicationTests {

	@Test
	void contextLoads() {
	}

}
