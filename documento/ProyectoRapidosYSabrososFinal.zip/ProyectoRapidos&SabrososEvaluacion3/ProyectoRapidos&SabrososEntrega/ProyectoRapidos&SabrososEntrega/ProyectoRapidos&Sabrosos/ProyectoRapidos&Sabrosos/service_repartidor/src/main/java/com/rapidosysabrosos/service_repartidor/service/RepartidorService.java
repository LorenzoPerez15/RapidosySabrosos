package com.rapidosysabrosos.service_repartidor.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rapidosysabrosos.service_repartidor.model.Repartidor;
import com.rapidosysabrosos.service_repartidor.repository.RepartidorRepository;

@Service
public class RepartidorService {

    @Autowired
    private RepartidorRepository repartidorRepository;

    public List<Repartidor> listarRepartidores() {
        return repartidorRepository.findAll();
    }

    public Repartidor buscarPorId(Long id) {
        return repartidorRepository.findById(id).orElse(null);
    }

    public Repartidor guardar(Repartidor repartidor) {
        return repartidorRepository.save(repartidor);
    }

    public Repartidor actualizar(Long id, Repartidor repartidor) {

        Repartidor existente = repartidorRepository.findById(id).orElse(null);

        if (existente != null) {
            existente.setNombreRepartidor(repartidor.getNombreRepartidor());
            existente.setTelefonoRepartidor(repartidor.getTelefonoRepartidor());
            existente.setTipoVehiculo(repartidor.getTipoVehiculo());
            existente.setPatente(repartidor.getPatente());
            existente.setIdEnvio(repartidor.getIdEnvio());

            return repartidorRepository.save(existente);
        }

        return null;
    }

    public void eliminar(Long id) {
        repartidorRepository.deleteById(id);
    }
}