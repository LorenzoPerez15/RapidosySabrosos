package com.rapidosysabrosos.service_repartidor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rapidosysabrosos.service_repartidor.model.Repartidor;
import com.rapidosysabrosos.service_repartidor.service.RepartidorService;

@RestController
@RequestMapping("/api/v1/repartidores")
public class RepartidorController {

    @Autowired

    private RepartidorService repartidorService;

    @GetMapping
    public List<Repartidor> listarRepartidores() {
        return repartidorService.listarRepartidores();
    }

    @GetMapping("/{id}")
    public Repartidor buscarPorId(@PathVariable Long id) {
        return repartidorService.buscarPorId(id);
    }

    @PostMapping
    public Repartidor guardar(@RequestBody Repartidor repartidor) {
        return repartidorService.guardar(repartidor);
    }

    @PutMapping("/{id}")
    public Repartidor actualizar(@PathVariable Long id,
                                 @RequestBody Repartidor repartidor) {
        return repartidorService.actualizar(id, repartidor);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        repartidorService.eliminar(id);
    }
}

