package com.rapidosysabrosos.service_repartidor.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RepartidorDTO {

    private Long idRepartidor;
    private Long telefonoRepartidor;
    private String nombreRepartidor;
    private String tipoVehiculo;
    private String patente;
    private Long idEnvio;

}