package com.rapidosysabrosos.service_proveedor.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rapidosysabrosos.service_proveedor.model.Proveedor;

@Repository

public interface ProveedorRepository extends JpaRepository<Proveedor, Long>{

    //Buscar por nombre de proveedor
    Proveedor findByNombreProveedor(String nombreProveedor);

}
