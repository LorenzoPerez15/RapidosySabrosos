package com.rapidosysabrosos.service_proveedor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceProveedorApplicationTests {

	@Test
	void contextLoads() {
	}

}
