package com.rapidosysabrosos.service_proveedor.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rapidosysabrosos.service_proveedor.model.Proveedor;
import com.rapidosysabrosos.service_proveedor.repository.ProveedorRepository;

import jakarta.transaction.Transactional;

@Service

public class ProveedorService {
    
    @Autowired
    private ProveedorRepository proveedorRepository;

    // ================= PROVEEDORES =================
    // Listar todos los proveedores
    public List<Proveedor> listarProveedores() {
        return proveedorRepository.findAll();
    }

    // Buscar proveedor por ID
    public Optional<Proveedor> buscarProveedorPorId(Long id) {
        return proveedorRepository.findById(id);
    }

    // Guardar proveedor
    @Transactional
    public Proveedor guardarProveedor(Proveedor proveedor) {
        return proveedorRepository.save(proveedor);
    }

    // Eliminar proveedor
    public void eliminarProveedor(Long id) {
        proveedorRepository.deleteById(id);
    }

    // Actualizar proveedor
    @Transactional
    public Proveedor actualizar(Long id, Proveedor proveedor) {
        proveedor.setId_proveedor(id);
        return proveedorRepository.save(proveedor);
    }
}
