package com.rapidosysabrosos.service_cupon.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.rapidosysabrosos.service_cupon.Model.Cupon;
import com.rapidosysabrosos.service_cupon.Repository.CuponRepository1;
import com.rapidosysabrosos.service_cupon.Service.CuponService;

@ExtendWith(MockitoExtension.class)
public class CuponServiceTest {
    @Mock
    private CuponRepository1 cuponRepository;
    @InjectMocks
    private CuponService cuponService;
    @Test
    @DisplayName("Test para validar el servicio de cupones")
    void guardarCuponTest() {
        // Aquí puedes agregar la lógica para probar el método de guardar cupones
        Cupon cupon = new Cupon();
        cupon.setCodigo("DESCUENTO10");
        cupon.setPorcentajeDescuento(10);
        
        when(cuponRepository.save(any(Cupon.class))).thenAnswer(invocation -> {
            Cupon c = invocation.getArgument(0);
            c.setIdCupo(1L); // Simula la asignación de ID al guardar
            return c;
        });

        Cupon resultado = cuponService.guardarCupon(cupon);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getIdCupo());
        assertEquals("DESCUENTO10", resultado.getCodigo());

        verify(cuponRepository, times(1)).save(any(Cupon.class));
    }

}
