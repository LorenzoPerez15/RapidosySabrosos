package com.rapidosysabrosos.service_cupon.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rapidosysabrosos.service_cupon.Model.Cupon;
import com.rapidosysabrosos.service_cupon.Service.CuponService;



@RestController
@RequestMapping("/ap1/v1/cupon")
public class CuponController {
    @Autowired
    private CuponService cuponService;

    @GetMapping
    public List<Cupon> listarCupones() {
        return cuponService.ListarTodos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Cupon> obtenerCuponPorId(@PathVariable Long id){
        return cuponService.obtenerCuponPorId(id)
                .map(cupon -> ResponseEntity.ok().body(cupon))
                .orElse(ResponseEntity.notFound().build());

    }

    @PostMapping
    public ResponseEntity<Cupon> crearCupon(@RequestBody Cupon cupon) {
        return ResponseEntity.ok(cuponService.guardarCupon(cupon));
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id){
        cuponService.eliminarCupon(id);
    }

    
}
