package com.rapidosysabrosos.service_cupon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceCuponApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceCuponApplication.class, args);
	}

}
