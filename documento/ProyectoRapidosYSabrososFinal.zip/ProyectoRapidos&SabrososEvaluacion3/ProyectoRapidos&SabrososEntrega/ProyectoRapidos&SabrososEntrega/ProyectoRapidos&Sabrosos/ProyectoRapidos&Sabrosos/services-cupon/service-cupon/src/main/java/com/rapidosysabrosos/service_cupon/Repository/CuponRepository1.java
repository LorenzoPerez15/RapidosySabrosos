package com.rapidosysabrosos.service_cupon.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rapidosysabrosos.service_cupon.Model.Cupon;

@Repository
public interface CuponRepository1 extends JpaRepository<Cupon, Long> {

}
