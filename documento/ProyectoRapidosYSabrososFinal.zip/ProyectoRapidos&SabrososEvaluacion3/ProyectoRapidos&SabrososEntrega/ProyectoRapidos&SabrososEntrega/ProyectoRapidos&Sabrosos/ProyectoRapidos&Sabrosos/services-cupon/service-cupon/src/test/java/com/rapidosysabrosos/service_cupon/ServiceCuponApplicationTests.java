package com.rapidosysabrosos.service_cupon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceCuponApplicationTests {

	@Test
	void contextLoads() {
	}

}
