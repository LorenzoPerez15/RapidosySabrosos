package com.rapidosysabrosos.service_cupon.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rapidosysabrosos.service_cupon.Model.Cupon;
import com.rapidosysabrosos.service_cupon.Repository.CuponRepository1;

@Service    
public class CuponService {
    @Autowired
    private CuponRepository1 cuponRepository;
    public List<Cupon> ListarTodos() {
        return cuponRepository.findAll();
    }
    public Cupon guardarCupon(Cupon cupon) {
        return cuponRepository.save(cupon);
    }
    public Optional<Cupon> obtenerCuponPorId(Long id) {
        return cuponRepository.findById(id);
    }
    public void eliminarCupon(Long id) {
        cuponRepository.deleteById(id);
    }
}
