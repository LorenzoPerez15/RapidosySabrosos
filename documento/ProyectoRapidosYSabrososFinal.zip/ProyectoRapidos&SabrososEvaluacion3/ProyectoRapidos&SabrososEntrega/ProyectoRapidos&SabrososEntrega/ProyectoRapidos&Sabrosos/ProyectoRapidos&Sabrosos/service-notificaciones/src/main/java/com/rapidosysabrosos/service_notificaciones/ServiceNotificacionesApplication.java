package com.rapidosysabrosos.service_notificaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceNotificacionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceNotificacionesApplication.class, args);
	}

}
