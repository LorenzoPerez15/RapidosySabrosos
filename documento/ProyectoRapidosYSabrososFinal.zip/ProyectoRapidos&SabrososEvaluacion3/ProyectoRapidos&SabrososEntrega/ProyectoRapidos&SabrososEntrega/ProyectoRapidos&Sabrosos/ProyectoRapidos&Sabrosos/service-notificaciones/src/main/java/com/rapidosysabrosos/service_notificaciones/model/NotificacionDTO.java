package com.rapidosysabrosos.service_notificaciones.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NotificacionDTO {
    private Long id;
    private String mensaje;
    private String tipo;
    private String fechaEnvio;
    private Long idCliente;
}