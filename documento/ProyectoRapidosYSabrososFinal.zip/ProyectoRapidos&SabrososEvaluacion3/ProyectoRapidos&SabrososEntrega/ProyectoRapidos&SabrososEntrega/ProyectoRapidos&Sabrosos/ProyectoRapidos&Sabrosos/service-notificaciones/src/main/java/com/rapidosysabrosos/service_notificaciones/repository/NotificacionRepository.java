package com.rapidosysabrosos.service_notificaciones.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rapidosysabrosos.service_notificaciones.model.Notificacion;

public interface NotificacionRepository extends JpaRepository<Notificacion, Long> {

}