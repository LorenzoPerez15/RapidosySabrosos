package com.rapidosysabrosos.service_notificaciones.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.rapidosysabrosos.service_notificaciones.model.Notificacion;
import com.rapidosysabrosos.service_notificaciones.repository.NotificacionRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;

@ExtendWith(MockitoExtension.class)
class NotificacionServiceTest {

    @Mock
    private NotificacionRepository notificacionRepository;

    @InjectMocks
    private NotificacionService notificacionService;

    @Test
    @DisplayName("Debería guardar una notificación correctamente")
    void guardarNotificacionTest() {

        // 1. Preparación
        Notificacion notificacion = new Notificacion();
        notificacion.setMensaje("Pedido entregado");
        notificacion.setTipo("INFORMATIVA");
        notificacion.setFechaEnvio(LocalDate.now());
        notificacion.setIdCliente(1L);

        // Simulamos el guardado
        when(notificacionRepository.save(any(Notificacion.class))).thenAnswer(invocation -> {
            Notificacion n = invocation.getArgument(0);
            n.setIdNotificacion(1L);
            return n;
        });

        // 2. Ejecución
        Notificacion resultado = notificacionService.guardar(notificacion);

        // 3. Verificación
        assertNotNull(resultado);
        assertEquals(1L, resultado.getIdNotificacion());
        assertEquals("Pedido entregado", resultado.getMensaje());
        assertEquals("INFORMATIVA", resultado.getTipo());
        assertEquals(1L, resultado.getIdCliente());

        // Verificamos que save() fue llamado una vez
        verify(notificacionRepository, times(1)).save(notificacion);
    }
}