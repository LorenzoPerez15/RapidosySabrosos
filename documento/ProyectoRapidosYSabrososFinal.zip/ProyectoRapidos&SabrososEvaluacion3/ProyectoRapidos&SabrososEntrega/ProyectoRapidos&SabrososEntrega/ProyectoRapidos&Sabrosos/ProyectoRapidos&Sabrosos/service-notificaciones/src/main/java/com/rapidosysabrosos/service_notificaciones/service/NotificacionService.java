package com.rapidosysabrosos.service_notificaciones.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rapidosysabrosos.service_notificaciones.model.Notificacion;
import com.rapidosysabrosos.service_notificaciones.repository.NotificacionRepository;

@Service
public class NotificacionService {

    @Autowired
    private NotificacionRepository notificacionRepository;

    public List<Notificacion> listarNotificaciones() {
        return notificacionRepository.findAll();
    }

    public Notificacion buscarPorId(Long id) {
        return notificacionRepository.findById(id).orElse(null);
    }

    public Notificacion guardar(Notificacion notificacion) {
        return notificacionRepository.save(notificacion);
    }

    public Notificacion actualizar(Long id, Notificacion notificacion) {

        Notificacion existente = notificacionRepository.findById(id).orElse(null);

        if (existente != null) {
            existente.setMensaje(notificacion.getMensaje());
            existente.setTipo(notificacion.getTipo());
            existente.setFechaEnvio(notificacion.getFechaEnvio());
            existente.setIdCliente(notificacion.getIdCliente());

            return notificacionRepository.save(existente);
        }

        return null;
    }

    public void eliminar(Long id) {
        notificacionRepository.deleteById(id);
    }
}
