package com.rapidosysabrosos.service_pagos.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rapidosysabrosos.service_pagos.Model.Pago;
import com.rapidosysabrosos.service_pagos.Repository.PagoRepository;

@Service
public class PagoService {

    @Autowired
    private PagoRepository pagoRepository;

    public List <Pago> listarTodos(){
        return pagoRepository.findAll();
    }

    public Optional <Pago> buscarPorId(Long id){
        return pagoRepository.findById(id);
    }

    public Pago guardar (Pago pago){
        return pagoRepository.save(pago);
    }


    public Pago actualizar(Long id, Pago pago){
        Pago pagoExistente = pagoRepository.findById(id).orElse(null);
    

    if(pagoExistente != null){
        pagoExistente.setMonto(pago.getMonto());
        pagoExistente.setMetodoPago(pago.getMetodoPago());
        pagoExistente.setEstado(pago.getEstado());
        pagoExistente.setFechaPago(pago.getFechaPago());
        pagoExistente.setIdCliente(pago.getIdCliente());
        pagoExistente.setIdPedido(pago.getIdPedido());

        return pagoRepository.save(pagoExistente);

    }
    return null;
    }
    
    public void eliminarPorId(Long id){
        pagoRepository.deleteById(id);
    }

}    