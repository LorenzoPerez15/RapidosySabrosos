package com.rapidosysabrosos.service_pagos.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rapidosysabrosos.service_pagos.Model.Pago;

@Repository

public interface PagoRepository extends JpaRepository<Pago, Long>{

    
}
