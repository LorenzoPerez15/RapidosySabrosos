package com.rapidosysabrosos.service_productos.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rapidosysabrosos.service_productos.Repository.CategoriaRepository;
import com.rapidosysabrosos.service_productos.model.Categoria;

@RestController
@RequestMapping("/api/v1/productos/categorias")

public class CategoriaController {

    @Autowired // Esto es para manejar automáticamente los tipos de datos
    private CategoriaRepository repository;

    @GetMapping
    public List<Categoria> listar(){
        return repository.findAll();

    }

    @PostMapping
    public Categoria crear(@RequestBody Categoria categoria){
        return repository.save(categoria);

    }

}
