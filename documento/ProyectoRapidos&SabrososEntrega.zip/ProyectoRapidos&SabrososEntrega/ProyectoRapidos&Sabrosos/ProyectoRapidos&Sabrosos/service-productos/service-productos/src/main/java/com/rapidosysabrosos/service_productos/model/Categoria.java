package com.rapidosysabrosos.service_productos.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name = "categoria")
@AllArgsConstructor

public class Categoria {

    @Id // Indica la clave primaria
    @GeneratedValue(strategy = GenerationType.IDENTITY)// Auto incremento en la base de datos
    private Long id_categoria;

    @Column(name = "nombre", nullable = false)// Campo obligatorio (no puede ser null)
    private String nombre;

    @OneToMany(mappedBy = "categoria", cascade = CascadeType.ALL)
    private List<Producto> productos;

}
