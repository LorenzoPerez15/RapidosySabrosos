package com.rapidosysabrosos.service_productos.Repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.rapidosysabrosos.service_productos.model.Producto;


@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long>{


    // Buscar por nombre (útil para catálogo)
    List<Producto> findByNombre(String nombre);

    // Reportes: cantidad de productos por categoría
    @Query("""
        SELECT p.categoria.nombre AS categoria,
            COUNT(p) AS cantidad
        FROM Producto p
        GROUP BY p.categoria.nombre
    """)
    List<Object[]> conteoPorCategoria();

    // Productos con categoría (para mostrar info completa)

    // El FETCH se utiliza para traer la relación completa
    @Query("""
        SELECT p FROM Producto p
        JOIN FETCH p.categoria c
    """)
    List<Producto> findProductosConCategoria();


}
