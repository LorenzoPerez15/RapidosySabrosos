package com.rapidosysabrosos.service_productos.Service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rapidosysabrosos.service_productos.Repository.CategoriaRepository;
import com.rapidosysabrosos.service_productos.Repository.ProductoRepository;
import com.rapidosysabrosos.service_productos.model.Categoria;
import com.rapidosysabrosos.service_productos.model.Producto;
import org.springframework.transaction.annotation.Transactional;
@Service

public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private CategoriaRepository categoriaRepository;

    // ================= PRODUCTOS =================

    // Listar todos los productos
    public List<Producto> listarProductos(){
        return productoRepository.findAll();
    }

    // Buscar producto por ID
    public Optional<Producto> buscarProductoPorId(Long id){
        return productoRepository.findById(id);
    }

    // Guardar producto
    @Transactional
    public Producto guardarProducto(Producto producto){
        return productoRepository.save(producto);
    }

    // Eliminar producto
    public void eliminarProducto(Long id){
        productoRepository.deleteById(id);
    }

     // ================= CATEGORÍAS =================

    // Listar categorías
    public List<Categoria> listarCategorias(){
        return categoriaRepository.findAll();
    }

    // Buscar categoría por ID
    public Optional<Categoria> buscarCategoriaPorId(Long id){
        return categoriaRepository.findById(id);
    }

    // Guardar categoría
    public Categoria guardarCategoria(Categoria categoria){
        return categoriaRepository.save(categoria);
    }

    // Eliminar categoría
    public void eliminarCategoria(Long id){
        categoriaRepository.deleteById(id);
    }
}
