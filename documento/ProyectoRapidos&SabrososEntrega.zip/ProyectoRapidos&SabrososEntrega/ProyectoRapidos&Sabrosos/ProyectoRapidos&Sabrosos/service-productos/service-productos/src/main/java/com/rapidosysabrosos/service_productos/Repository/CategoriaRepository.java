package com.rapidosysabrosos.service_productos.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rapidosysabrosos.service_productos.model.Categoria;

@Repository

public interface CategoriaRepository extends JpaRepository<Categoria, Long>{

    Categoria findByNombre(String nombre);

    Categoria findByNombreIgnoreCase(String nombre);

}
