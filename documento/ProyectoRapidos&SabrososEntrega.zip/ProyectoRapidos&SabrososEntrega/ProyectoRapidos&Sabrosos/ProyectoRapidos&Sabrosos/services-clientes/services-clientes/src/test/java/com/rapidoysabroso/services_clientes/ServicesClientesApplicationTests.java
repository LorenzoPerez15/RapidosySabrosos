package com.rapidoysabroso.services_clientes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicesClientesApplicationTests {

	@Test
	void contextLoads() {
	}

}
