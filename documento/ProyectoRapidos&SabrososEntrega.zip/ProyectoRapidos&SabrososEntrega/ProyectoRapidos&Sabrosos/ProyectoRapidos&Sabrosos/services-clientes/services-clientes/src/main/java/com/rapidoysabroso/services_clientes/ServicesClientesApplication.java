package com.rapidoysabroso.services_clientes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicesClientesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicesClientesApplication.class, args);
	}

}
