package com.rapidoysabroso.services_clientes.Services;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rapidoysabroso.services_clientes.Model.Cliente;
import com.rapidoysabroso.services_clientes.Repository.ClienteRepository;



@Service
public class ClienteService {


    //Inyectar el repositorio
    @Autowired
    private ClienteRepository clienteRepository;
    //Metodo para listar todos los clientes
    public List<Cliente> listarTodos(){
        return clienteRepository.findAll();
    }
    //Metodo para encontrar un cliente por su id
    public Optional<Cliente> buscarPorId(Long id){
        return clienteRepository.findById(id);
    }
    //Metodo para guardar un cliente
    // public String guardar(Cliente cliente){
    // //el correo está vacío o solo tiene espacios
    // if(cliente.getCorreo() == null || cliente.getCorreo().trim().isEmpty() || !cliente.getCorreo().contains("@")){
    // return "Correo no válido";
    // }
    // clienteRepository.save(cliente);
    // return "Cliente guardado correctamente";
    // }
    public Cliente guardar(Cliente cliente){
    if(cliente.getCorreo() == null || cliente.getCorreo().trim().isEmpty() || !cliente.getCorreo().contains("@")){
        return null;
    }
    return clienteRepository.save(cliente);
    }
    // if(cliente.getCorreo() == null || !cliente.getCorreo().contains("@")){
    //     return null;
    // }
    
    public Cliente actualizar(Long id, Cliente cliente){
    //Buscas el cliente en la base de datos por su ID.
    //Optional significa “puede existir o no”.
    Optional<Cliente> clienteExistente = clienteRepository.findById(id);
    //“¿el cliente existe?”
    if(clienteExistente.isPresent()){
        //“¿el cliente existe?”, Esto es seguro SOLO porque antes validaste con isPresent().
        Cliente clienteActualizado = clienteExistente.get();

        if(cliente.getNombre() != null){
            clienteActualizado.setNombre(cliente.getNombre());
        }

        if(cliente.getApellido() != null){
            clienteActualizado.setApellido(cliente.getApellido());
        }

        if(cliente.getCorreo() != null && cliente.getCorreo().contains("@")){
            clienteActualizado.setCorreo(cliente.getCorreo());
        }

        if(cliente.getTelefono() != null){
            clienteActualizado.setTelefono(cliente.getTelefono());
        }

        if(cliente.getDireccion() != null){
            clienteActualizado.setDireccion(cliente.getDireccion());
        }

        return clienteRepository.save(clienteActualizado);
    }

    return null;
}

    //Metodo para eliminar un cliente por su id
    public void eliminarPorId(Long id){
        clienteRepository.deleteById(id);
    }
}

