package com.rapidoysabroso.services_clientes.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rapidoysabroso.services_clientes.Model.Cliente;

@Repository
public interface ClienteRepository  extends  JpaRepository<Cliente, Long> {
    //Buscar por run (util para el cliente)
    Cliente findByRun(String run);
}
