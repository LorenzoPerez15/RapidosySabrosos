package com.rapidosysabrosos.envio_service.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.rapidosysabrosos.envio_service.model.Envio;
import com.rapidosysabrosos.envio_service.repository.EnvioRepository;

@Service

public class EnvioService {

    @Autowired
    private EnvioRepository envioRepository;

    @Autowired
    private WebClient.Builder webClientBuilder;

    // LISTAR TODOS
    public List<Envio> listarTodos(){
        return envioRepository.findAll();
    }

    // BUSCAR POR ID
    public Optional<Envio> buscarPorId(Long id){
        return envioRepository.findById(id);
    }

    // GUARDAR
    public Envio guardar(Envio envio){
        Envio guardado = envioRepository.save(envio);

        Envio completo = envioRepository.findById(
            guardado.getIdEnvio()
        ).orElse(guardado);

        return enriquecerConPedido(completo);
    }

    // ELIMINAR
    public void eliminar(Long id){
        envioRepository.deleteById(id);
    }

    // OBTENER ENVIO COMPLETO
    public Envio obtenerEnvioCompleto(Long id){
        Envio envio = envioRepository.findById(id).orElse(null);

        if(envio != null){
            return enriquecerConPedido(envio);
        }

        return null;
    }

     // ================= WEBCLIENT PEDIDOS =================

    private Envio enriquecerConPedido(Envio envio){

        if(envio.getPedidoId() != null){

            try{

                Object pedido = webClientBuilder.build()
                    .get()
                    .uri("http://localhost:8082/api/v1/pedidos/" + envio.getPedidoId())
                    .retrieve()
                    .bodyToMono(Object.class)
                    .block();

                envio.setDatosPedido(pedido);

            }catch(Exception e){

                envio.setDatosPedido("Información del pedido no disponible");
            }
        }

        return envio;
    }

}
