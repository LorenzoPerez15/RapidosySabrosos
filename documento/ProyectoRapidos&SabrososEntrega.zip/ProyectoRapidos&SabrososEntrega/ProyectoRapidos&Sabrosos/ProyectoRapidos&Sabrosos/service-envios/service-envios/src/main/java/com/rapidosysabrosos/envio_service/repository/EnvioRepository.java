package com.rapidosysabrosos.envio_service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rapidosysabrosos.envio_service.model.Envio;

public interface EnvioRepository extends JpaRepository<Envio, Long>{

     // Buscar envíos por estado
    List<Envio> findByEstadoEnvio(String estadoEnvio);

    // Buscar envíos por tipo
    List<Envio> findByTipoEnvio(String tipoEnvio);

    // Buscar envíos por pedido
    List<Envio> findByPedidoId(Long pedidoId);

}
