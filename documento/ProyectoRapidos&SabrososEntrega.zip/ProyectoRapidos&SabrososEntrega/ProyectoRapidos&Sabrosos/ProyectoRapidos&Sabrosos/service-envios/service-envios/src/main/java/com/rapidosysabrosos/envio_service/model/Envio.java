package com.rapidosysabrosos.envio_service.model;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "envios")


public class Envio {

     // ID autoincremental
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idEnvio;

    private String direccionEnvio;
    private String estadoEnvio;
    private String tipoEnvio;
    private LocalDate fechaEnvio;

    // FK lógica al microservicio pedidos
    private Long pedidoId;

    // Datos obtenidos desde WebClient
    @Transient
    private Object datosPedido;

}
