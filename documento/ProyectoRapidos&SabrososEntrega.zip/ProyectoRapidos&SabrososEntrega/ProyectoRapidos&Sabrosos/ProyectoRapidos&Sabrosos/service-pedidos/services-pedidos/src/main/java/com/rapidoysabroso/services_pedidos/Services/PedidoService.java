package com.rapidoysabroso.services_pedidos.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.rapidoysabroso.services_pedidos.Model.DetallePedido;
import com.rapidoysabroso.services_pedidos.Model.Pedido;
import com.rapidoysabroso.services_pedidos.Repository.DetallePedidoRepository;
import com.rapidoysabroso.services_pedidos.Repository.PedidoRepository;

@Service
public class PedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;

    @Autowired
    private DetallePedidoRepository detallePedidoRepository;

    @Autowired
    private WebClient.Builder webClientBuilder;

    // ===================== PEDIDO =====================

    /**
     * Guarda el pedido junto con sus detalles en cascada.
     * El JSON del body puede incluir una lista "detalles" directamente.
     */
    public Pedido guardarPedido(Pedido pedido) {
        // Aseguramos la relación bidireccional antes de persistir
        if (pedido.getDetalles() != null) {
            pedido.getDetalles().forEach(detalle -> detalle.setPedido(pedido));
        }
        return pedidoRepository.save(pedido);
    }

    public Pedido obtenerPedido(Long id) {
        return pedidoRepository.findById(id).orElse(null);
    }

    public List<Pedido> listarPedidos() {
        return pedidoRepository.findAll();
    }

    public void eliminarPedidoPorId(Long id) {
        pedidoRepository.deleteById(id);
    }

    // ===================== DETALLE =====================

    /**
     * Guarda un detalle suelto y lo enriquece con datos externos.
     */
    public DetallePedido guardarDetallePedido(DetallePedido detalle) {
        // Si viene con pedido referenciado, lo resolvemos para tener el objeto completo
        if (detalle.getPedido() != null && detalle.getPedido().getIdPedido() != null) {
            Pedido pedido = pedidoRepository
                    .findById(detalle.getPedido().getIdPedido())
                    .orElse(null);
            detalle.setPedido(pedido);
        }

        DetallePedido guardado = detallePedidoRepository.save(detalle);
        return enriquecerConCliente(enriquecerConProducto(guardado));
    }

    public DetallePedido obtenerDetallePedidoCompleto(Long id) {
        return detallePedidoRepository.findById(id)
                .map(d -> enriquecerConCliente(enriquecerConProducto(d)))
                .orElse(null);
    }

    public Pedido obtenerPedidoCompleto(Long id) {
    Pedido pedido = pedidoRepository.findById(id).orElse(null);
    if (pedido == null) return null;

    List<DetallePedido> detallesEnriquecidos = pedido.getDetalles()
            .stream()
            .map(d -> enriquecerConCliente(enriquecerConProducto(d)))
            .toList();

    pedido.setDetalles(detallesEnriquecidos);
    return pedido;
}

    public List<DetallePedido> listarTodos() {
        return detallePedidoRepository.findAll()
                .stream()
                .map(d -> enriquecerConCliente(enriquecerConProducto(d)))
                .toList();
    }

    public void eliminarDetallePorId(Long id) {
        detallePedidoRepository.deleteById(id);
    }

    // ===================== ENRIQUECIMIENTO =====================

    private DetallePedido enriquecerConProducto(DetallePedido detalle) {
        if (detalle.getProductoId() == null) return detalle;
        try {
            Object producto = webClientBuilder.build()
                    .get()
                    .uri("http://localhost:8083/api/v1/productos/" + detalle.getProductoId())
                    .retrieve()
                    .bodyToMono(Object.class)
                    .block();
            detalle.setDatosProducto(producto);
        } catch (Exception e) {
            detalle.setDatosProducto("Información del producto no disponible");
        }
        return detalle;
    }

    private DetallePedido enriquecerConCliente(DetallePedido detalle) {
        // Necesitamos el pedido y su clienteId para buscar el cliente
        if (detalle.getPedido() == null || detalle.getPedido().getClienteId() == null) return detalle;
        try {
            Object cliente = webClientBuilder.build()
                    .get()
                    .uri("http://localhost:8081/api/v1/clientes/" + detalle.getPedido().getClienteId())
                    .retrieve()
                    .bodyToMono(Object.class)
                    .block();
            detalle.setDatosCliente(cliente);
        } catch (Exception e) {
            detalle.setDatosCliente("Información del cliente no disponible");
        }
        return detalle;
    }
}
