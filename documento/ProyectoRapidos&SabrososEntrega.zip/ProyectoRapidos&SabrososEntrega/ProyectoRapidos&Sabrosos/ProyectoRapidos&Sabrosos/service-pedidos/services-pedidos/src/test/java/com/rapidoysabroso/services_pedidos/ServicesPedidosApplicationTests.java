package com.rapidoysabroso.services_pedidos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicesPedidosApplicationTests {

	@Test
	void contextLoads() {
	}

}
