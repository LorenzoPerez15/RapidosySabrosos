package com.rapidoysabroso.services_pedidos.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rapidoysabroso.services_pedidos.Model.DetallePedido;

public interface DetallePedidoRepository extends JpaRepository<DetallePedido, Long> {

}
