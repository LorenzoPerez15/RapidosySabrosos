package com.rapidoysabroso.services_pedidos.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rapidoysabroso.services_pedidos.Model.DetallePedido;
import com.rapidoysabroso.services_pedidos.Services.PedidoService;

@RestController
@RequestMapping("/api/v1/pedidos")
public class DetallePedidoController {

    @Autowired
    private PedidoService pedidoService;

    // POST /api/v1/pedidos/detalles
    @PostMapping("/detalles")
    public ResponseEntity<DetallePedido> crear(@RequestBody DetallePedido detalle) {
        DetallePedido nuevo = pedidoService.guardarDetallePedido(detalle);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevo);
    }

    // GET /api/v1/pedidos/detalles
    @GetMapping("/detalles")
    public ResponseEntity<List<DetallePedido>> listar() {
        return ResponseEntity.ok(pedidoService.listarTodos());
    }

    // GET /api/v1/pedidos/detalles/{id}
    @GetMapping("/detalles/{id}")
    public ResponseEntity<DetallePedido> verDetalle(@PathVariable Long id) {
        DetallePedido detalle = pedidoService.obtenerDetallePedidoCompleto(id);
        if (detalle == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(detalle);
    }

    // DELETE /api/v1/pedidos/detalles/{id}
    @DeleteMapping("/detalles/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        pedidoService.eliminarDetallePorId(id);
        return ResponseEntity.noContent().build();
    }
}
