package com.rapidoysabroso.services_pedidos.Repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.rapidoysabroso.services_pedidos.Model.Pedido;


public interface PedidoRepository extends  JpaRepository<Pedido, Long>{
    
}
