package com.rapidoysabroso.services_pedidos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicesPedidosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicesPedidosApplication.class, args);
	}

}
